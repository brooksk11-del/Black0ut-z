// ===== Game Variables =====
let scrap = 0;
let caps = 0;
let stage = 1;
let autoClickers = 0;
let strength = 1;
let allies = [];
let backpack = [];

// ===== Rarities =====
const rarities = [
  { name: "Common", color: "gray", bonus: 1, chance: 0.6 },
  { name: "Rare", color: "blue", bonus: 2, chance: 0.25 },
  { name: "Epic", color: "purple", bonus: 4, chance: 0.1 },
  { name: "Legendary", color: "gold", bonus: 8, chance: 0.05 }
];

function getRarity() {
  let roll = Math.random();
  let sum = 0;
  for (let r of rarities) {
    sum += r.chance;
    if (roll <= sum) return r;
  }
  return rarities[0]; // fallback
}

// ===== DOM =====
const scrapCount = document.getElementById("scrapCount");
const capsCount = document.getElementById("capsCount");
const stageInfo = document.getElementById("stageInfo");
const log = document.getElementById("log");
const backpackDiv = document.getElementById("backpack");
const allyList = document.getElementById("allyList");

// ===== Logging =====
function addLog(msg) {
  log.innerHTML += `<p>> ${msg}</p>`;
  log.scrollTop = log.scrollHeight;
}

// ===== Scrap Clicking =====
document.getElementById("scrapBtn").onclick = () => {
  scrap += strength;
  scrapCount.textContent = "Scrap: " + scrap;
  if (Math.random() < 0.2) {
    caps++;
    capsCount.textContent = "Caps: " + caps;
    addLog("Found 1 cap!");
  }
};

// ===== Upgrades =====
document.getElementById("buyAutoClicker").onclick = () => {
  if (scrap >= 10) {
    scrap -= 10;
    autoClickers++;
    addLog("Bought an auto clicker.");
  }
};

document.getElementById("buyStrength").onclick = () => {
  if (scrap >= 20) {
    scrap -= 20;
    strength++;
    addLog("Strength increased to " + strength);
  }
};

// Auto clicker loop
setInterval(() => {
  scrap += autoClickers;
  scrapCount.textContent = "Scrap: " + scrap;
}, 1000);

// ===== Stages & Bosses =====
document.getElementById("fightBossBtn").onclick = () => {
  let bossHP = stage * 10;
  let dmg = strength + allies.length * 2;
  addLog("Fighting Boss of Stage " + stage);

  if (dmg >= bossHP) {
    addLog("Boss defeated!");
    stage++;
    stageInfo.textContent = "Stage: " + stage;
  } else {
    addLog("Defeated by Boss! Retry...");
  }
};

// ===== Allies =====
document.getElementById("hireAlly").onclick = () => {
  if (scrap >= 50) {
    scrap -= 50;
    let ally = { name: "Ally #" + (allies.length + 1), hat: null };
    allies.push(ally);
    updateAllies();
    addLog(ally.name + " joined your team!");
  }
};

function updateAllies() {
  allyList.innerHTML = "";
  allies.forEach(a => {
    allyList.innerHTML += `<p>${a.name}</p>`;
  });
}

// ===== Shop with Rarity =====
document.getElementById("buyWeapon").onclick = () => {
  if (caps >= 5) {
    caps -= 5;
    let rarity = getRarity();
    let weapon = { 
      type: "Weapon", 
      rarity: rarity.name, 
      color: rarity.color, 
      power: (Math.floor(Math.random() * 5) + 1) * rarity.bonus 
    };
    backpack.push(weapon);
    updateBackpack();
    addLog(`Bought a ${rarity.name} weapon (+${weapon.power} strength).`);
  }
};

document.getElementById("buyArmor").onclick = () => {
  if (caps >= 5) {
    caps -= 5;
    let rarity = getRarity();
    let armor = { 
      type: "Armor", 
      rarity: rarity.name, 
      color: rarity.color, 
      defense: (Math.floor(Math.random() * 5) + 1) * rarity.bonus 
    };
    backpack.push(armor);
    updateBackpack();
    addLog(`Bought ${rarity.name} armor (+${armor.defense} defense).`);
  }
};

// ===== Backpack =====
function updateBackpack() {
  backpackDiv.innerHTML = "";
  backpack.forEach((item, i) => {
    let stats = item.type === "Weapon" 
      ? `Power: ${item.power}` 
      : `Defense: ${item.defense}`;
    backpackDiv.innerHTML += `<p style="color:${item.color}">[${i + 1}] ${item.rarity} ${item.type} (${stats})</p>`;
  });
}